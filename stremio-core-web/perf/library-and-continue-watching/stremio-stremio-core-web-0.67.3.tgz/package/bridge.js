"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
var _regenerator = _interopRequireDefault(require("@babel/runtime/regenerator"));
var _asyncToGenerator2 = _interopRequireDefault(require("@babel/runtime/helpers/asyncToGenerator"));
function getId() {
  return Math.random().toString(32).slice(2);
}
function Bridge(scope, handler) {
  var pending = new Map();
  handler.addEventListener('message', function (_ref) {
    var response = _ref.data.response;
    var callbacks = response && pending.get(response.id);
    if (!callbacks) return;
    pending["delete"](response.id);
    if ('error' in response.result) {
      callbacks.reject(response.result.error);
    } else {
      callbacks.resolve(response.result.data);
    }
  });
  handler.addEventListener('message', /*#__PURE__*/function () {
    var _ref3 = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee(_ref2) {
      var request, id, path, args, value, data, thisArg;
      return _regenerator["default"].wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            request = _ref2.data.request;
            if (request) {
              _context.next = 3;
              break;
            }
            return _context.abrupt("return");
          case 3:
            id = request.id, path = request.path, args = request.args;
            _context.prev = 4;
            value = path.reduce(function (value, prop) {
              return value[prop];
            }, scope);
            if (!(typeof value === 'function')) {
              _context.next = 13;
              break;
            }
            thisArg = path.slice(0, path.length - 1).reduce(function (value, prop) {
              return value[prop];
            }, scope);
            _context.next = 10;
            return value.apply(thisArg, args);
          case 10:
            data = _context.sent;
            _context.next = 16;
            break;
          case 13:
            _context.next = 15;
            return value;
          case 15:
            data = _context.sent;
          case 16:
            handler.postMessage({
              response: {
                id: id,
                result: {
                  data: data
                }
              }
            });
            _context.next = 22;
            break;
          case 19:
            _context.prev = 19;
            _context.t0 = _context["catch"](4);
            handler.postMessage({
              response: {
                id: id,
                result: {
                  error: _context.t0
                }
              }
            });
          case 22:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[4, 19]]);
    }));
    return function (_x) {
      return _ref3.apply(this, arguments);
    };
  }());
  this.call = /*#__PURE__*/function () {
    var _ref4 = (0, _asyncToGenerator2["default"])( /*#__PURE__*/_regenerator["default"].mark(function _callee2(path, args) {
      var id;
      return _regenerator["default"].wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            id = getId();
            return _context2.abrupt("return", new Promise(function (resolve, reject) {
              pending.set(id, {
                resolve: resolve,
                reject: reject
              });
              handler.postMessage({
                request: {
                  id: id,
                  path: path,
                  args: args
                }
              });
            }));
          case 2:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }));
    return function (_x2, _x3) {
      return _ref4.apply(this, arguments);
    };
  }();
}
module.exports = Bridge;
